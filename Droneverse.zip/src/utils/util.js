export function classNames(...classes) {
    return classes.join(' ');
}